package id.anarchyvoid.death;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class AnarchyVoidDeath extends JavaPlugin implements Listener {
    private final Map<UUID, PrisonRecord> prisoners = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;
    private BukkitTask ticker;
    private final MiniMessage mini = MiniMessage.miniMessage();

    private record PrisonRecord(long releaseAt, String world, double x, double y, double z,
                                float yaw, float pitch) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "players.yml");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        ticker = Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        getLogger().info("AnarchyVoidDeath enabled.");
    }

    @Override public void onDisable() {
        if (ticker != null) ticker.cancel();
        saveData();
    }

    private void loadData() {
        if (!dataFile.exists()) {
            try { getDataFolder().mkdirs(); dataFile.createNewFile(); }
            catch (IOException e) { getLogger().severe("Cannot create players.yml: " + e.getMessage()); }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        if (data.getConfigurationSection("players") == null) return;
        for (String key : data.getConfigurationSection("players").getKeys(false)) {
            String p = "players." + key + ".";
            prisoners.put(UUID.fromString(key), new PrisonRecord(
                data.getLong(p + "release-at"),
                data.getString(p + "world", "world"),
                data.getDouble(p + "x"), data.getDouble(p + "y"), data.getDouble(p + "z"),
                (float)data.getDouble(p + "yaw"), (float)data.getDouble(p + "pitch")
            ));
        }
    }

    private void saveData() {
        if (data == null) return;
        data.set("players", null);
        for (var entry : prisoners.entrySet()) {
            String p = "players." + entry.getKey() + ".";
            PrisonRecord r = entry.getValue();
            data.set(p + "release-at", r.releaseAt());
            data.set(p + "world", r.world());
            data.set(p + "x", r.x()); data.set(p + "y", r.y()); data.set(p + "z", r.z());
            data.set(p + "yaw", r.yaw()); data.set(p + "pitch", r.pitch());
        }
        try { data.save(dataFile); }
        catch (IOException e) { getLogger().severe("Cannot save players.yml: " + e.getMessage()); }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player p = event.getEntity();
        Location back = p.getLocation();
        long releaseAt = System.currentTimeMillis() + getConfig().getLong("cooldown-seconds", 600) * 1000L;
        prisoners.put(p.getUniqueId(), new PrisonRecord(releaseAt,
            back.getWorld().getName(), back.getX(), back.getY(), back.getZ(), back.getYaw(), back.getPitch()));
        event.deathMessage(mini.deserialize(getConfig().getString(
            "death-message", "<dark_purple>Jiwamu telah ditarik dan dibawa ke Void...")));
        saveData();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        PrisonRecord record = prisoners.get(event.getPlayer().getUniqueId());
        if (record == null) return;
        Location voidLoc = configuredLocation("void-world", "void-spawn");
        if (voidLoc == null) {
            getLogger().severe("Void world not found. Create it and restart/reload the plugin.");
            return;
        }
        event.setRespawnLocation(voidLoc);
        Bukkit.getScheduler().runTask(this, () -> {
            Player p = event.getPlayer();
            if (p.isOnline() && prisoners.containsKey(p.getUniqueId())) {
                p.setGameMode(GameMode.ADVENTURE);
                p.setFlying(false);
                p.setWalkSpeed(0f);
                p.setFlySpeed(0f);
                p.sendMessage(mini.deserialize(getConfig().getString(
                    "death-message", "<dark_purple>Jiwamu telah ditarik dan dibawa ke Void...")));
                showTimer(p, prisoners.get(p.getUniqueId()));
            }
        });
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        PrisonRecord r = prisoners.get(p.getUniqueId());
        if (r == null) return;
        if (System.currentTimeMillis() >= r.releaseAt()) {
            release(p, r);
        } else {
            Location v = configuredLocation("void-world", "void-spawn");
            if (v != null) p.teleport(v);
            lock(p);
            showTimer(p, r);
        }
    }

    @EventHandler public void onMove(PlayerMoveEvent event) {
        if (!prisoners.containsKey(event.getPlayer().getUniqueId())) return;
        if (event.getTo() == null) return;
        if (event.getFrom().getX() != event.getTo().getX()
            || event.getFrom().getY() != event.getTo().getY()
            || event.getFrom().getZ() != event.getTo().getZ()) {
            event.setTo(event.getFrom());
        }
    }

    @EventHandler public void onInteract(PlayerInteractEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onDrop(PlayerDropItemEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onPickup(PlayerAttemptPickupItemEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onDamage(org.bukkit.event.entity.EntityDamageEvent event) {
        if (event.getEntity() instanceof Player p && isPrisoner(p)) event.setCancelled(true);
    }
    @EventHandler public void onCommand(PlayerCommandPreprocessEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onChat(AsyncPlayerChatEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player p && isPrisoner(p)) event.setCancelled(true);
    }
    @EventHandler public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player p && isPrisoner(p)) event.setCancelled(true);
    }
    @EventHandler public void onBlockBreak(BlockBreakEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onBlockPlace(BlockPlaceEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onConsume(PlayerItemConsumeEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }
    @EventHandler public void onPortal(PlayerPortalEvent event) {
        if (isPrisoner(event.getPlayer())) event.setCancelled(true);
    }

    private boolean isPrisoner(Player p) { return prisoners.containsKey(p.getUniqueId()); }
    private void lock(Player p) {
        p.setGameMode(GameMode.ADVENTURE);
        p.setWalkSpeed(0f); p.setFlySpeed(0f);
        p.setFlying(false);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (var entry : new HashMap<>(prisoners).entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            if (now >= entry.getValue().releaseAt()) {
                // Keep expired records while offline; onJoin() will release them.
                if (p != null) release(p, entry.getValue());
            } else if (p != null) showTimer(p, entry.getValue());
        }
    }

    private void showTimer(Player p, PrisonRecord r) {
        long seconds = Math.max(0, (r.releaseAt() - System.currentTimeMillis()) / 1000);
        String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
        String raw = getConfig().getString("timer-message", "<light_purple>Kebangkitan dalam: <white>{time}")
            .replace("{time}", time);
        p.sendActionBar(mini.deserialize(raw));
    }

    private void release(Player p, PrisonRecord r) {
        Location back = new Location(Bukkit.getWorld(r.world()), r.x(), r.y(), r.z(), r.yaw(), r.pitch());
        if (back.getWorld() == null) back = configuredLocation("return-world", "return-spawn");
        if (back == null) {
            getLogger().severe("Return world is missing; cannot release " + p.getName());
            return;
        }
        prisoners.remove(p.getUniqueId());
        p.setWalkSpeed(0.2f); p.setFlySpeed(0.1f);
        p.setGameMode(GameMode.SURVIVAL);
        p.teleport(back);
        p.sendMessage(mini.deserialize(getConfig().getString(
            "released-message", "<green>Jiwamu telah dikembalikan. Selamat datang kembali.")));
        saveData();
    }

    private Location configuredLocation(String worldKey, String spawnKey) {
        World w = Bukkit.getWorld(getConfig().getString(worldKey, "world"));
        if (w == null) return null;
        String path = spawnKey + ".";
        return new Location(w, getConfig().getDouble(path + "x", 0.5),
            getConfig().getDouble(path + "y", 100), getConfig().getDouble(path + "z", 0.5),
            (float)getConfig().getDouble(path + "yaw", 0),
            (float)getConfig().getDouble(path + "pitch", 0));
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("anarchyvoiddeath.admin")) {
            sender.sendMessage("No permission."); return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig(); sender.sendMessage("AnarchyVoidDeath config reloaded."); return true;
        }
        sender.sendMessage("Usage: /avdeath reload"); return true;
    }
}
