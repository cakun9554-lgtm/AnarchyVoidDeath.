AnarchyVoidDeath - source project

Build on GitHub (Android-friendly):
1. Upload the whole project to a GitHub repository, including the hidden .github folder.
2. Open the repository's Actions tab.
3. Select "Build AnarchyVoidDeath" and press Run workflow.
4. Open the completed run and download the "AnarchyVoidDeath-JAR" artifact.
5. Extract the artifact ZIP; it contains AnarchyVoidDeath-1.0.0.jar.
6. Put the JAR in the server plugins folder and restart the server.

Requirements:
- Paper server with Bukkit/Paper API compatibility.
- Multiverse-Core (or another world manager) to create/load the configured VoidPrison world.
- Edit plugins/AnarchyVoidDeath/config.yml after first start.

Default cooldown is 600 seconds (10 minutes). The release timestamp uses system time,
so the cooldown continues while the player is offline. Expired offline records are kept
until the player joins, then they are released.

Build dependency currently targets Paper API 1.21.4 for broad API compatibility.
Test on a backup/staging server before production, especially on newer Paper builds.
